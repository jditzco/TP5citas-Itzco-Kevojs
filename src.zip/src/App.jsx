import { useState } from 'react'
import './App.css'
import Cita from './Components/Cita'
import Form from './Components/Form'


function App() {

  const [citas, setCitas] = useState([])
  const pushCitas = data => {
    let newCitas = [...citas]
    newCitas.push(data)
    newCitas = newCitas.reverse()
    setCitas(newCitas)
  }
  return (
    <>
      <h1>ADMINISTRADOR DE PACIENTES</h1>
      <div className='container'>
        <div className='row'>
          <div className='one-half column'>
            <h2>Crear mi cita</h2>
            <Form submit={pushCitas} />
          </div>
          <div className='one-half column'>
            <h2>Administra tus citas</h2>
            {citas.length ? citas.map((e, key) => (
              <Cita key={key} mascota={e.mascota} dueño={e.dueño} fecha={e.fecha} hora={e.hora} sintomas={e.sintomas} />
            )) : <h5>Acá aparecerán tus citas</h5>}
          </div>
        </div>
      </div>
    </>
  )
}

export default App
