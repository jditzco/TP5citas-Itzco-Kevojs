import { useState } from "react"
import './Cita.css'

function Cita({ mascota, dueño, fecha, hora, sintomas } ) {

  const [eliminado, setEliminado] = useState(false)
  const handleClick = e => setEliminado(!eliminado)

  return !eliminado &&
    <div className='cita'>
        <p><b>Mascota:</b> {mascota}</p>
        <p><b>Dueño:</b> {dueño}</p>
        <p><b>Fecha:</b> {fecha}</p>
        <p><b>Hora:</b> {hora}</p>
        <p><b>Sintomas:</b> {sintomas}</p>
        <button className="button elimnar u-full-width" onClick={handleClick}>Eliminar ×</button>
    </div>
}

export default Cita
